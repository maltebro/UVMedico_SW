Load a Lottie animation from raw data
"""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/rlottie/lv_example_rlottie_1
  :language: c

Load a Lottie animation from a file
"""""""""""""""""""""""""""""""""""

.. lv_example:: libs/rlottie/lv_example_rlottie_2
  :language: c

